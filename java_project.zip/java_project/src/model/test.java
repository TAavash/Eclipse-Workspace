package model;

public class test {
	public static int customer_customer_id;
	public static int booking_booking_id;
	public static int room_room_id;
	
	
}
